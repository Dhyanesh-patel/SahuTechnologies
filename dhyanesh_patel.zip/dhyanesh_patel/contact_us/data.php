<?php
session_start();
extract($_POST);
$fname = $_POST["name"];
$mobile = $_POST["mobile"];
$email = $_POST["email"];



$conn = new mysqli('127.0.0.1', 'root', '', 'contact_us');
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
 } 
$stmt = $conn->prepare("INSERT INTO data (name, mobile, email, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $fname, $mobile, $email, $message);
$stmt->execute();
$stmt->close();
$conn->close();
 
header("Location: index.html")
?>